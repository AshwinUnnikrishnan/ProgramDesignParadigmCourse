

import org.junit.Before;
import org.junit.Test;

import calculator.Calculator;

import static org.junit.Assert.assertEquals;

/**
 * Abstract test class that contains common test to test both the calculators.
 */
abstract class AbstractCalculatorTest {
  protected Calculator temp;

  /**
   * Abstract function which will be implemented by classes that implement this, it returns the
   * reference of the object of new class.
   *
   * @return Returns the respective objects of the class.
   */
  abstract Calculator createObj();

  /**
   * Setup performed before each test runs.
   */
  @Before
  public void setup() {
    temp = createObj();
  }

  /**
   * Test to check SimpleCalculator constructor is getting stored as
   * result.
   * First Input Argument Test 1
   */
  @Test
  public void testInitialState() {
    assertEquals("", temp.getResult());
  }

  /**
   * Method to test when digit is entered first.
   * First Input Argument Test 2
   */
  @Test
  public void testInputMethodSingleDigitFirstNumber() {
    temp = temp.input('1');
    assertEquals("1", temp.getResult());
  }

  /**
   * Method to test if - operator raises exception.
   * First Input Argument Test 3
   */
  @Test(expected = IllegalArgumentException.class)
  public void testInputNegativeFirstCharacter() {
    temp = temp.input('-');
  }

  /**
   * Method to test if * operator raises exception.
   * First Input Argument Test 4
   */
  @Test(expected = IllegalArgumentException.class)
  public void testInputMultiplicationFirstCharacter() {
    temp = temp.input('*');
  }

  /**
   * Method to test if = operator raises exception.
   * First Input Argument Test 6
   */
  @Test
  public void testEqualOperatorFirstCharacter() {
    temp = temp.input('=');
    assertEquals("", temp.getResult());
  }

  /**
   * Method to test if = operator raises exception.
   * First Input Argument Test 7
   */
  @Test
  public void testResetFirstCharacter() {
    temp = temp.input('C');
    assertEquals("", temp.getResult());
  }

  /**
   * Method to test if CC operator resets calculator.
   * First Input Argument Test 8
   */
  @Test
  public void testResetMultipleFirstCharacter() {
    temp = temp.input('C');
    temp = temp.input('C');
    assertEquals("", temp.getResult());
  }

  /**
   * Method to test if == operator resets calculator.
   * First Input Argument Test 9
   */
  @Test
  public void testEqualMultipleFirstCharacter() {
    temp = temp.input('=');
    temp = temp.input('=');
    assertEquals("", temp.getResult());
  }

  /**
   * Method to test if ++ operator resets calculator.
   * First Input Argument Test 10
   */
  @Test(expected = IllegalArgumentException.class)
  public void testMinusMultipleFirstCharacter() {
    temp = temp.input('-');
    temp = temp.input('-');
  }

  /**
   * Test to see if calculator works when multiple digits come in the first number.
   * First Number Test 1
   */
  @Test
  public void testMultipleDigitInput() {
    temp = temp.input('1');
    temp = temp.input('2');
    temp = temp.input('3');
    temp = temp.input('4');
    assertEquals("1234", temp.getResult());
  }

  /**
   * Test to see if calculator works first number overflows.
   * First Number Test 2
   */
  @Test(expected = IllegalArgumentException.class)
  public void testOverflowFirstNumber() {
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
  }

  /**
   * Test to see if calculator state after it raises exception for first number overflow.
   * First Number Test 3
   */
  @Test
  public void testOverflowFirstNumberAndResult() {
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    try {
      temp = temp.input('1');
    } catch (IllegalArgumentException e) {
      //
    }
    assertEquals("1111111111", temp.getResult());

  }

  /**
   * Test to check operation C after a number is present in calculator.
   * Non Digit Character After First Number Test 1
   */
  @Test
  public void testCleanSheetOnC() {
    temp = temp.input('1');
    temp = temp.input('2');
    temp = temp.input('3');
    temp = temp.input('4');
    temp = temp.input('C');
    assertEquals("", temp.getResult());
  }

  /**
   * Test to check operation = after a number is present in calculator.
   * Non Digit Character After First Number Test 2
   */
  @Test
  public void testEqualAfterFirstNumber() {
    temp = temp.input('1');
    temp = temp.input('=');
    assertEquals("1", temp.getResult());
  }

  /**
   * Test to check operation + after a number is present in calculator.
   * Non Digit Character After First Number Test 3
   */
  @Test
  public void testOperatorAfterNumber() {
    temp = temp.input('5');
    temp = temp.input('+');
    assertEquals("5+", temp.getResult());
  }

  /**
   * Test to check operation - after a number is present in calculator.
   * Non Digit Character After First Number Test 4
   */
  @Test
  public void testMinusOperatorAfterNumber() {
    temp = temp.input('5');
    temp = temp.input('-');
    assertEquals("5-", temp.getResult());
  }

  /**
   * Test to check operation * after a number is present in calculator.
   * Non Digit Character After First Number Test 5
   */
  @Test
  public void testMultiplyOperatorAfterNumber() {
    temp = temp.input('5');
    temp = temp.input('*');
    assertEquals("5*", temp.getResult());
  }

  /**
   * Test to check operation * after a number and reset raises error.
   * Operator After Operator First Number Test 1
   */
  @Test(expected = IllegalArgumentException.class)
  public void testMultiplyAfterNumberAndReset() {
    temp = temp.input('5');
    temp = temp.input('C');
    temp = temp.input('*');
  }

  /**
   * Test to check operation * after a number and = raises error.
   * Operator After Operator First Number Test 2
   */
  @Test
  public void testMultiplyAfterNumberAndEqual() {
    temp = temp.input('5');
    temp = temp.input('=');
    temp = temp.input('*');
    assertEquals("5*", temp.getResult());
  }

  /**
   * Test to check operation C after a number and + resets it.
   * Operator After Operator First Number Test 5
   */
  @Test
  public void testCAfterNumberAndPlus() {
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('C');
    assertEquals("", temp.getResult());
  }

  /**
   * Test to check operation = after a number and =.
   * Operator After Operator First Number Test 6
   */
  @Test
  public void testMultipleEqualAfterFirstNumber() {
    temp = temp.input('2');
    temp = temp.input('7');
    temp = temp.input('=');
    temp = temp.input('=');
    assertEquals("27", temp.getResult());
  }

  /**
   * Test to check second number after first number and equal.
   * Second Number Test 1
   */
  @Test
  public void testSecondNumberAfterEqual() {
    temp = temp.input('2');
    temp = temp.input('7');
    temp = temp.input('=');
    temp = temp.input('9');
    assertEquals("9", temp.getResult());
  }

  /**
   * To test number after operator.
   * Second Number Test 2
   */
  @Test
  public void testNumberAfterOperator() {
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('5');
    assertEquals("5555+5", temp.getResult());
  }

  /**
   * Test adding digit in the second number.
   * Second Number Test 3
   */
  @Test
  public void testNumberAfterNumberOperator() {
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('5');
    temp = temp.input('5');
    assertEquals("5555+55", temp.getResult());
  }

  /**
   * Test adding digit in the second number and overflowing.
   * Second Number Test 4
   */
  @Test(expected = IllegalArgumentException.class)
  public void testOverflowSecondNumber() {
    temp = temp.input('1');
    temp = temp.input('+');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
  }

  /**
   * Test adding digit in the second number and result after overflowing.
   * Second Number Test 5
   */
  @Test
  public void testStatusAfterSecondNumberOverflow() {
    temp = temp.input('1');
    temp = temp.input('+');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('1');
    try {
      temp = temp.input('1');
    } catch (IllegalArgumentException e) {
      //
    }
    assertEquals("1+1111111111", temp.getResult());
  }

  /**
   * Test to check Add operation between two numbers Equal.
   * Two Number Operation Test 1
   */
  @Test
  public void testTwoNumberAdd() {
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('5');
    temp = temp.input('=');
    assertEquals("10", temp.getResult());
  }

  /**
   * Test to check Add operation between two numbers Plus.
   * Two Number Operation Test 2
   */
  @Test
  public void testTwoNumberAddFollowedAdd() {
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('5');
    temp = temp.input('+');
    assertEquals("10+", temp.getResult());
  }

  /**
   * Test to check Multiply operation between two numbers Equal.
   * Two Number Operation Test 3
   */
  @Test
  public void testTwoNumberMultiply() {
    temp = temp.input('5');
    temp = temp.input('*');
    temp = temp.input('5');
    temp = temp.input('=');
    assertEquals("25", temp.getResult());
  }

  /**
   * Test to check Subtract operation between two numbers Equal.
   * Two Number Operation Test 4
   */
  @Test
  public void testTwoNumberSubtract() {
    temp = temp.input('5');
    temp = temp.input('-');
    temp = temp.input('5');
    temp = temp.input('=');
    assertEquals("0", temp.getResult());
  }

  /**
   * Test to check Subtract operation between two numbers resulting negative Equal.
   * Two Number Operation Test 5
   */
  @Test
  public void testTwoNumberSubtractResultNegative() {
    temp = temp.input('5');
    temp = temp.input('-');
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('=');
    assertEquals("-50", temp.getResult());
  }

  /**
   * Test to check Subtract operation between two numbers resulting negative and perform operation
   * on the number.
   * Two Number Operation Test 6
   */
  @Test
  public void testTwoNumberSubtractResultNegativeOperationAfter() {
    temp = temp.input('5');
    temp = temp.input('-');
    temp = temp.input('5');
    temp = temp.input('5');
    temp = temp.input('=');
    temp = temp.input('*');
    temp = temp.input('5');
    temp = temp.input('=');
    assertEquals("-250", temp.getResult());
  }

  /**
   * Test to check Add operation between two numbers Plus.
   * Two Number Operation Test 7
   */
  @Test
  public void testTwoNumberSubtractFollowedAdd() {
    temp = temp.input('5');
    temp = temp.input('-');
    temp = temp.input('1');
    temp = temp.input('5');
    temp = temp.input('+');
    assertEquals("-10+", temp.getResult());
  }

  /**
   * Test to check Operation after getting negative number.
   * Two Number Operation Test 8
   */
  @Test
  public void testNegativeValueOperations() {
    temp = temp.input('5');
    temp = temp.input('-');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('*');
    temp = temp.input('2');
    assertEquals("-6*2", temp.getResult());
  }

  /**
   * Test to check Operation after getting negative number.
   * Two Number Operation Test 9
   */
  @Test
  public void testNegativeValueOperationsEquals() {
    temp = temp.input('5');
    temp = temp.input('-');
    temp = temp.input('1');
    temp = temp.input('1');
    temp = temp.input('*');
    temp = temp.input('2');
    temp = temp.input('=');
    assertEquals("-12", temp.getResult());
  }

  /**
   * Test to check addition leading to overflow.
   * Two Number Operation Test 10
   */
  @Test
  public void testAdditionLeadingToOverflow() {
    temp = temp.input('2');
    temp = temp.input('1');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('4');
    temp = temp.input('8');
    temp = temp.input('3');
    temp = temp.input('6');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('+');
    temp = temp.input('9');
    temp = temp.input('=');
    assertEquals("0", temp.getResult());
  }

  /**
   * Test to check multiply leading to overflow.
   * Two Number Operation Test 11
   */
  @Test
  public void testMultiplicationLeadingToOverflow() {
    temp = temp.input('2');
    temp = temp.input('1');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('4');
    temp = temp.input('8');
    temp = temp.input('3');
    temp = temp.input('6');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('*');
    temp = temp.input('9');
    temp = temp.input('=');
    assertEquals("0", temp.getResult());
  }

  /**
   * Test to check subtraction leading to overflow.
   * Two Number Operation Test 12
   */
  @Test
  public void testSubtractionLeadingToOverflow() {
    temp = temp.input('0');
    temp = temp.input('-');
    temp = temp.input('2');
    temp = temp.input('1');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('4');
    temp = temp.input('8');
    temp = temp.input('3');
    temp = temp.input('6');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('*');
    temp = temp.input('9');
    temp = temp.input('=');
    assertEquals("0", temp.getResult());
  }

  /**
   * Test to check subtraction leading negative max value.
   * Two Number Operation Test 13
   */
  @Test
  public void testSubtractionLeadingNegativeMax() {
    temp = temp.input('0');
    temp = temp.input('-');
    temp = temp.input('2');
    temp = temp.input('1');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('4');
    temp = temp.input('8');
    temp = temp.input('3');
    temp = temp.input('6');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('-');
    temp = temp.input('1');
    temp = temp.input('=');
    assertEquals("-2147483648", temp.getResult());
  }

  /**
   * Test to check result after random operations.
   * Two Number Operation Test 15
   */
  @Test
  public void testRandom() {
    temp = temp.input('3');
    temp = temp.input('2');
    temp = temp.input('+');
    temp = temp.input('2');
    temp = temp.input('2');
    temp = temp.input('-');
    temp = temp.input('2');
    temp = temp.input('2');
    temp = temp.input('-');
    temp = temp.input('6');
    temp = temp.input('2');

    temp = temp.input('*');
    temp = temp.input('2');
    temp = temp.input('=');
    temp = temp.input('*');

    temp = temp.input('2');
    temp = temp.input('=');

    assertEquals("-120", temp.getResult());
  }

  /**
   * Test to check working with random characters. Random characters in second operand.
   * Random Characters Test 1
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRandomCharacters() {
    temp = temp.input('-');
    temp = temp.input('2');
    temp = temp.input('+');
    temp = temp.input('2');
    temp = temp.input('a');
  }

  /**
   * Test to check working with random characters. Random characters in first operand.
   * Random Characters Test 2
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRandomCharactersFirstOperand() {
    temp = temp.input('1');
    temp = temp.input('2');
    temp = temp.input('a');
  }

  /**
   * Test to check working with random characters. Random characters in third operand.
   * Random Characters Test 3
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRandomCharacterThirdOperand() {
    temp = temp.input('1');
    temp = temp.input('2');
    temp = temp.input('+');
    temp = temp.input('2');
    temp = temp.input('+');
    temp = temp.input('a');
  }

}
