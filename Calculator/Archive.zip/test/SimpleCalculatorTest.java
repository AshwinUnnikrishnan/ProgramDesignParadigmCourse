import org.junit.Test;

import calculator.Calculator;
import calculator.SimpleCalculator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Class to test Simple Calculator.
 */
public class SimpleCalculatorTest extends AbstractCalculatorTest {

  @Override
  Calculator createObj() {
    return new SimpleCalculator();
  }

  /**
   * Method to test if + operator raises exception.
   * First Input Argument Test 5
   */
  @Test(expected = IllegalArgumentException.class)
  public void testInputPlusFirstCharacter() {
    temp = temp.input('+');
  }

  /**
   * Test to check operation * after a number and * raises error.
   * Operator After Operator First Number Test 3
   */
  @Test(expected = IllegalArgumentException.class)
  public void testMultiplyAfterNumberAndPlus() {
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('*');
  }

  /**
   * Test to check operation = after a number and * raises error.
   * Operator After Operator First Number Test 4
   */
  @Test(expected = IllegalArgumentException.class)
  public void testEqualAfterNumberAndMultiply() {
    temp = temp.input('5');
    temp = temp.input('*');
    temp = temp.input('=');
  }

  /**
   * Test to check operation = after a number, operator and =.
   * Operator After Operator First Number Test 7
   */
  @Test(expected = IllegalArgumentException.class)
  public void testMultipleEqualAfterFirstNumberOperator() {
    temp = temp.input('2');
    temp = temp.input('7');
    temp = temp.input('+');
    temp = temp.input('=');
    temp = temp.input('=');
    assertEquals("27", temp.getResult());
  }

  /**
   * Test to check subtraction leading negative max value.
   * Two Number Operation Test 14
   */
  @Test
  public void testMultipleEqual() { // TODO unspecified so not ignoring can come back and work
    temp = temp.input('2');
    temp = temp.input('7');
    temp = temp.input('*');
    temp = temp.input('2');
    temp = temp.input('=');
    temp = temp.input('=');
    temp = temp.input('=');
    assertEquals("54", temp.getResult()); //should be 0
  }












































  @Test
  public void testZeroValues() { // TODO unspecified so not ignoring can come back and work
    temp = temp.input('0');
    temp = temp.input('0');
    assertEquals("00", temp.getResult()); //should be 0
  }







  @Test
  public void testFirstInputOperatorInvalid() {
    char[] operators = {'+', '-', '*'};
    for (char c : operators) {
      try {
        temp.input(c);
        fail("Did not raise IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        //
      }
    }
  }



  @Test
  public void testSample() {
    temp = temp.input('2');
    temp = temp.input('2');
    temp = temp.input('+');
    temp = temp.input('0');
    temp = temp.input('0');
    temp = temp.input('1');

    temp = temp.input('=');
    assertEquals("23", temp.getResult());
  }






  /*@Test
  public void testFizzyTesting() {
    //get random number between 1 and 5 number of digits in first operand
    //get random number between 1 and 5 number of digits in second operand
    //create both the numbers int and perform location operation based on random 3 select
    // check if answers match then continue generating numbers for second operand and insert and
    // operations

  }
*/

}