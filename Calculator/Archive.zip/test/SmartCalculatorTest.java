import org.junit.Test;

import calculator.Calculator;
import calculator.SmartCalculator;

import static org.junit.Assert.assertEquals;

/**
 * Test class for smart calculator.
 */
public class SmartCalculatorTest extends AbstractCalculatorTest {


  /**
   * Abstract function which will be implemented by classes that implement this, it returns the
   * reference of the object of new class.
   *
   * @return returns a SmartCalculator
   */
  @Override
  Calculator createObj() {
    return new SmartCalculator();
  }

  /**
   * Method to test if + operator does nothing.
   * First Input Argument Test 5
   */
  @Test
  public void testInputPlusFirstCharacter() {
    temp = temp.input('+');
    assertEquals("", temp.getResult());
  }

  /**
   * Test to check operation * after a number and + replaces with new operator.
   * Operator After Operator First Number Test 3
   */
  @Test
  public void testMultiplyAfterNumberAndPlus() {
    temp = temp.input('5');
    temp = temp.input('+');
    temp = temp.input('*');
    assertEquals("5*", temp.getResult());
  }

  /**
   * Test to check operation = after a number and * uses the first number as second operand as well.
   * Operator After Operator First Number Test 4
   */
  @Test
  public void testEqualAfterNumberAndMultiply() {
    temp = temp.input('5');
    temp = temp.input('*');
    temp = temp.input('=');
    assertEquals("25", temp.getResult());
  }

  /**
   * Test to check operation = after a number, operator and =.
   * Operator After Operator First Number Test 7
   */
  @Test
  public void testMultipleEqualAfterFirstNumberOperator() {
    temp = temp.input('2');
    temp = temp.input('7');
    temp = temp.input('+');
    temp = temp.input('=');
    temp = temp.input('=');
    assertEquals("81", temp.getResult());
  }

  /**
   * Test to check subtraction leading negative max value.
   * Two Number Operation Test 14
   */
  @Test
  public void testMultipleEqual() { // TODO unspecified so not ignoring can come back and work
    temp = temp.input('2');
    temp = temp.input('7');
    temp = temp.input('*');
    temp = temp.input('2');
    temp = temp.input('=');
    temp = temp.input('=');
    temp = temp.input('=');
    assertEquals("216", temp.getResult()); //should be 0
  }


  @Test
  public void testZeroValues() { // TODO unspecified so not ignoring can come back and work
    temp = temp.input('0');
    temp = temp.input('0');
    assertEquals("00", temp.getResult()); //should be 0
  }


  @Test
  public void testSa() {
    // TODO unspecified so not ignoring can come back and work
    temp = temp.input('2');
    temp = temp.input('1');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('4');
    temp = temp.input('8');
    temp = temp.input('3');
    temp = temp.input('6');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('+');
    temp = temp.input('2');
    temp = temp.input('1');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('4');
    temp = temp.input('8');
    temp = temp.input('3');
    temp = temp.input('6');
    temp = temp.input('4');
    temp = temp.input('7');
    temp = temp.input('+');
    assertEquals("0", temp.getResult()); //should be 0
  }
}