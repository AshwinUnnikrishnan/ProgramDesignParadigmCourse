/**
 * Enum to represent black and white color pieces in chess.
 */
public enum Color {
  WHITE, BLACK
}
