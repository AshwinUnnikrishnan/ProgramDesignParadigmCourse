import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertEquals;

/**
 * A JUnit test class for the SimpleProjectile class.
 */
public class SimpleProjectileTest {

  private Particle negativeVerticalVelocityParticle;
  private Particle zeroHorizontalVelocity;
  private Particle zeroHorizontalMovement;

  @Before
  public void setUp() {
    negativeVerticalVelocityParticle = new SimpleProjectile(1, 1, 0,
            -10);
    zeroHorizontalVelocity = new SimpleProjectile(0, 0, 0,
            10);
    zeroHorizontalMovement = new SimpleProjectile(0, 0, 0,
            14);

  }

  @Test
  public void testNegativeTime() {
    String expectedOutput = "At time -1.00: position is (0.00,0.00)";
    assertEquals(expectedOutput, zeroHorizontalVelocity.getState(-1));
  }

  @Test
  public void testZeroHorizontalVelocity() {
    String expectedOutput = "At time 2.04: position is (0.00,0.00)";
    assertEquals(expectedOutput, zeroHorizontalVelocity.getState(2.04f));
  }

  @Test
  public void testNegativeVerticalVelocity() {
    String expectedOutput = "At time 2.04: position is (1.00,1.00)";
    assertEquals(expectedOutput, negativeVerticalVelocityParticle.getState(2.04f));
  }

  @Test
  public void noHorizontalMovement() {
    String expectedOutput = "At time 2.00: position is (0.00,8.38)";
    assertEquals(expectedOutput, zeroHorizontalMovement.getState(2.00f));
  }
  //time testing
  // test for negative time
  // test for timetohitgroundnotreached
  // test for timetohitgroundreached

  //velocity testing
  // check with 0 verticalVelocity
  // check with 0 horizontalVelocity

  //position testing
  // check with different variations of initial x position as y is constant 0
  // check if the position of x is negative

  //two decimal output testing
}