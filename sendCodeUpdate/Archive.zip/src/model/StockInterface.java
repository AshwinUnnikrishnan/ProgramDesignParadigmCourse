package model;

/**
 * Interface for the Stocks.
 */
public interface StockInterface {
}
